%KFtools
%(c) Keith Forbes 2001
%
%BNDREAD read boundary coordinates from a file.
%BNDWRITE writes boundary coordinates to a file.
%CETROIDMEX centroid of a binary image.
%GETBOUNDARYMEX returns boundary coordinates of a binary object in an image.
%PALETTEMEX create 3-band RGB image from marker image
%SELECTOBJECTMEX selects objects from a binary image.
%WATERSHEDMEX  watershed segmentation, flooding from selected sources.


