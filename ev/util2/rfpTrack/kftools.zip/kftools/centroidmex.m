%CETROIDMEX centroid of a binary image.
%   Z=CETROIDMEX(BW) returns the centroid in complex number form of
%   an object (ones) in a binary (zeros and ones) image BW.
%
%   Keith Forbes 2000 keith@umpire.com

function z=centroidmex(bw);
disp('Try running the mexKFtools script')
error('You must compile the mex file centroidmex.c to use this function.')


